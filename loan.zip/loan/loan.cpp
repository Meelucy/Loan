#include <iostream>
#include <fstream>
using namespace std;
string id[10];
	float amount;
	float sum;
	string name[10],nname, surname[10],ssurname,location[10],llocation,check;
	char symboll[10];
	int option;
	int del=1, count=0;
	string password[10],username[10],ppassword,cpassword;
	string eexit;
	char log;
	int x;
	int interest,inter,total;
	int money;
	int age;
	string region;
	string town,com;
	int confirm;
	

void menu(){
	cout<<"Select from the list below\n\n";
	cout<<"1. Login\n";
	cout<<"2. Apply for a Loan\n";
	cout<<"3. About Clients\n";
	cout<<"4. Check Interest Rates\n";
	cout<<"5. EXIT\n\n";
	cin>>option;
	
}
void logged(){
	cout<<"Select from the list below\n\n";
	cout<<"1. Apply for a Loan\n";
	cout<<"2. About Clients\n";
	cout<<"3. Check Interest Rates\n";
	cout<<"4. EXIT\n\n";
	cin>>option;
	system("cls");	
}
void testing(){
for(int t=0; t<count; t++){
	cout<<nname<<" "<<amount<<name[t]<<endl;

}
	
}
void interestt(){
 if(amount >=1000 && amount <10000){ 
   inter = 15;
   total= amount+(amount*0.15);
 }
  
   else if(amount < 20000)
   {
   	interest = 0.18;
   inter = 18;
     total= amount+(amount*0.18);
    }
   else if(amount <40000)
   {
   	interest = 0.21;
   inter = 21;
   total= amount+(amount*0.21);
   }
   else if(amount < 60000)
   {
   	interest = 0.25;
   inter = 25;
     total= amount+(amount*0.25);
   }
   else if(amount>= 60000)	
   {
   	interest = 0.28;
   inter = 28;
    total= amount+(amount*0.28);
   }
}
void checkinterest(){
	char see;
	cout<<"\nDo you want to check interest rates (y/n)\n";
	cin>>see;
while(see == 'y'){
	
	system("cls");
		
	cout<<"Enter Amount you want\n";
	cin>>amount;
	
	interestt();
	if(amount<1000)
	cout<<"Sory we don't offer Loans under E1000!\n";
	else
	{
	cout<<"Your interest rate is "<<inter<<"%"<<endl;
	cout<<"You will pay "<<total<<endl<<endl;
	}
	cout<<"\nDo you want to check interest rates again (y/n)\n";
	cin>>see;
	
}

	
} 
void applyLoan(){
	cout<<"Enter Name\n";
	cin>>nname;
	cout<<"Enter Surname\n";
	cin>>ssurname;
	cout<<"Enter age not under the age of 18\n";
    cin>>age;
    if(age<18){
    	cout<<"Sorry clients under the age of 18 are not allowed to apply for a loan\n";
    	
	}
	else
	{
    cout<<"Enter region\n";
	cin>>region;
	cout<<"Enter home town\n";
	cin>>town;
	cout<<"Enter community name\n";
	cin>>com;
	checkinterest();
	
	cout<<"Enter amount for the loan\n ";
	cin>>amount;
	if(amount <100)
	cout<<"Sory we don't orfer loans under E1000\n";
	else{
		cout<<"press 1 to confirm your loan of "<<amount<<endl;
		cin>>confirm;
		system ("cls");
		
		cout<<"Congratulation you have Successfuly make a loan of "<<amount<<endl<<endl;
		
		cout<<"Press 0 to EXIT\n";
		cin>>eexit;
		system ("cls");
	}
	
	}	
}
void aboutclients(){
	
	cout<<"NAME "<<nname<<endl;
	cout<<"SURNAME "<<ssurname<<endl;
	cout<<"REGION "<<region<<endl;
	cout<<"HOME TOWN "<<town<<endl;
	cout<<"COMMUNITY "<<com<<endl;
	cout<<"LOAN "<<amount<<endl<<endl;
	cout<<"Press 1 to EXIT \n";
	cin>>eexit;
	system("cls");
	
	ofstream display;
	display.open("client.txt");
    display<<"NAME "<<nname<<endl;
	display<<"SURNAME "<<surname<<endl;
	display<<"REGION "<<region<<endl;
	display<<"HOME TOWN "<<town<<endl;
	display<<"COMMUNITY "<<com<<endl;
	display<<"LOAN "<<amount<<endl<<endl;
	
}
void login(){

for( x; x<del; x++){
	del++;
	count++;
	cout<<"Enter Your password to login\n";
    		cin>>password[x];
    		system("cls");
    		
    		if(password[x]==check){
    			
    		logged();
    		switch(option){
    			
    			case 1: applyLoan();
    			        
    			        
    			break;
    			case 2:aboutclients();
    			break;
    			case 3: checkinterest();
    			break;
    		 	case 4:
    		 		del = 0;
    			       break;
    			
			}
    			
		    	}
		   
		   	else{
				
			cout<<"It seems like you don't have an account\n";
    		cout<<"Do you want to register an employee (y/n)\n";
    		cin>>log;
    		system("cls");
    		
    		if(log == 'y'){
    		cout<<"Enter user name\n";    		
    		cin>>username[x];
    		
    		
    		cout<<"Enter password\n";
    		cin>>password[x];
    		ppassword = password[x];
    		check = ppassword;
    		
    		cout<<"confirm the password\n";
    		cin>>cpassword;
    		if(cpassword != ppassword){
    			cout<<"your password does not match re-enter password\n";
    			cin>>cpassword;
    				if(cpassword != ppassword){
    					system("cls");
    					login();
					}
					else if(cpassword == ppassword){
			cout<<"You have successfuly created an account "<<username[x]<<endl<<endl;	
			cout<<"Enter any key to exit\n";
			cin>>eexit;
			system("cls");
			}
			else
			//del=0;
    		break;
    	
					}
						else if(cpassword == ppassword){
			cout<<"You have successfuly created an account "<<username[x]<<endl<<endl;	
			cout<<"Enter any key to exit\n";
			cin>>eexit;
			system("cls");
			}
			else
			//del=0;
    		break;
    			
			}
			else
			//del=0;
    		break;
    		}
            }	
            }      






int main(){
 int count=-1,cut=0;
string log;	

do{
	count++;
	
menu();
system("cls");
switch(option){
	   case 1: login();
	            break;
	   case 2:cout<<"You need to login fisrt\n\n";
	          login();
	          break;
	   case 3:cout<<"You need to login fisrt\n\n";
	         login();
	          break;
	   case 4:cout<<"You need to login fisrt\n\n";
	           login();
	          break; 
	   case 5:
	         break;     
}

	
	
}
while(cut=0);



	return 0;
}
